from .import students,teachers,fee_structure,enquire
from .import sale
from .import invoice
from .import suggestion1
from .import product_brand
from .import sale_order
from .import sale_report_xls
from .import res_config_settings
